package tss;

/** Common base interface for all interfaces representing TPM unions */
public interface TpmUnion extends TpmMarshaller {
}

